# Image Annotation Editor

Professional, free image annotation editor built with **Fabric.js** - works reliably on both mobile and desktop.

## 🎨 Features

✅ **Drawing Tools:**
- Brush with 3 stroke sizes (thin, medium, thick)
- Eraser tool
- Rectangle drawing (drag to create)
- Arrow annotation tool
- Text tool for labels

✅ **Colors:**
- 10 preset colors
- Custom color picker
- Easy color switching

✅ **Controls:**
- Undo last action
- Clear all annotations
- Select/move tool for repositioning

✅ **Quality:**
- High-quality export at original image resolution
- Preserves image quality
- PNG export format

✅ **Cross-Platform:**
- Works on desktop (mouse)
- Works on mobile (touch)
- Responsive design

## 📦 Installation

### 1. Install Dependencies

```bash
npm install fabric
# or
yarn add fabric
```

### 2. Add to Your Project

Copy these files to your project:
- `ImageAnnotatorModal.jsx` - Main component
- `ImageAnnotatorModal.css` - Styles

### 3. Import and Use

```jsx
import ImageAnnotatorModal from './components/ImageAnnotatorModal';
import './components/ImageAnnotatorModal.css';

function YourComponent() {
  const [editingFile, setEditingFile] = useState(null);

  const handleSave = (editedFile) => {
    // editedFile is a File object with the annotations
    console.log('Edited file:', editedFile);
    
    // Use it for upload, preview, etc.
    const formData = new FormData();
    formData.append('image', editedFile);
    
    setEditingFile(null);
  };

  return (
    <>
      <button onClick={() => {
        // Pass the file you want to edit
        setEditingFile(yourImageFile);
      }}>
        Edit Image
      </button>

      <ImageAnnotatorModal
        open={editingFile !== null}
        file={editingFile}
        onCancel={() => setEditingFile(null)}
        onSave={handleSave}
      />
    </>
  );
}
```

## 🔧 Integration with Purchase Form

Based on your use case, here's how to integrate with Add/Edit Purchase:

```jsx
// In PurchaseFormModal.jsx

import ImageAnnotatorModal from '../common/ImageAnnotatorModal';
import '../common/ImageAnnotatorModal.css';

function PurchaseFormModal() {
  const [newImages, setNewImages] = useState([]);
  const [editingImage, setEditingImage] = useState(null);

  const handleEditImage = (imageIndex) => {
    setEditingImage({
      index: imageIndex,
      file: newImages[imageIndex]
    });
  };

  const handleSaveEditedImage = (editedFile) => {
    setNewImages(prev => {
      const updated = [...prev];
      updated[editingImage.index] = editedFile;
      return updated;
    });
    setEditingImage(null);
  };

  return (
    <>
      {/* Your existing form */}
      
      {/* Image thumbnails with edit button */}
      {newImages.map((img, index) => (
        <div key={index} className="thumbnail">
          <img src={URL.createObjectURL(img)} alt="" />
          <button onClick={() => handleEditImage(index)}>
            تعديل {/* Edit in Arabic */}
          </button>
        </div>
      ))}

      {/* Editor modal */}
      {editingImage && (
        <ImageAnnotatorModal
          open={true}
          file={editingImage.file}
          onCancel={() => setEditingImage(null)}
          onSave={handleSaveEditedImage}
        />
      )}
    </>
  );
}
```

## 🎯 Key Implementation Details

### Coordinate System
- **Display:** Image is scaled to fit the modal
- **Storage:** All drawing operations stored in original image coordinates
- **Export:** Rendered at full original resolution (no quality loss)

### Performance Optimizations
- No base64 in React state during drawing
- Event listeners cleaned up on unmount
- Efficient canvas rendering
- Proper memory management

### Mobile Support
- Touch events work seamlessly
- Touch-action: none prevents page scroll while drawing
- Minimum 44px touch targets
- Responsive toolbar layout

## 🌐 Browser Support

- ✅ Chrome/Edge (Desktop & Mobile)
- ✅ Firefox (Desktop & Mobile)
- ✅ Safari (Desktop & iOS)
- ✅ Android Chrome

## 📱 Testing the Demo

Open `demo.html` in your browser to see a fully functional demo:

1. Upload one or more images
2. Click "Edit" on any image
3. Try all the tools
4. Save and see the edited version

## 🔍 Technical Architecture

```
ImageAnnotatorModal
├── Canvas Setup (Fabric.js)
│   ├── Load image with aspect ratio preservation
│   ├── Calculate display scale
│   └── Store original dimensions
│
├── Tool Configuration
│   ├── Brush (freehand drawing)
│   ├── Eraser (destination-out composition)
│   ├── Rectangle (drag to draw)
│   ├── Arrow (line + polyline head)
│   ├── Text (interactive IText)
│   └── Select (move/resize objects)
│
└── Export Logic
    ├── Create offscreen canvas at original size
    ├── Scale all objects to original coordinates
    ├── Render at 1:1 resolution
    └── Export as PNG Blob → File
```

## 💡 Tips

1. **For large images:** The editor automatically scales the display while preserving full quality on export
2. **Undo limitation:** Currently undoes one object at a time (can be extended to full history)
3. **Custom styling:** Modify `ImageAnnotatorModal.css` to match your app's design
4. **RTL support:** Interface is RTL-ready (Arabic text included)

## 🐛 Troubleshooting

**Problem:** Editor doesn't show
- Check if Fabric.js is loaded: `console.log(fabric)`
- Verify file is a valid image type

**Problem:** Drawings disappear on save
- Check browser console for errors
- Verify export canvas logic isn't being blocked

**Problem:** Slow performance on mobile
- Consider reducing max display size for very large images
- Ensure canvas size is reasonable

## 📄 License

Free to use - Fabric.js is MIT licensed

## 🎓 Credits

Built with:
- [Fabric.js](http://fabricjs.com/) - Canvas drawing library
- React - UI framework
